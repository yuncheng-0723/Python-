# 前言
使用Python開發俄羅斯方塊遊戲
 
# 範例詳細說明請參考以下連接   
[(新文章)【Python】那些年我們一起玩過的遊戲(二)-俄羅斯方塊](https://medium.com/@upgrades/python-%E9%82%A3%E4%BA%9B%E5%B9%B4%E6%88%91%E5%80%91%E4%B8%80%E8%B5%B7%E7%8E%A9%E9%81%8E%E7%9A%84%E9%81%8A%E6%88%B2-%E4%BA%8C-%E4%BF%84%E7%BE%85%E6%96%AF%E6%96%B9%E5%A1%8A-2250e08b72a6)

[(舊文章)【python】初體驗-俄羅斯方塊遊戲](http://webfish-channel.blogspot.tw/2017/11/python.html)
